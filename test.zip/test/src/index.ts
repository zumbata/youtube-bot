import bodyParser from "body-parser"
import express from "express"
import multer from "multer"
import * as nodemailer from "nodemailer"
import helpers from "handlebars-helpers"
import { MailOptions } from "nodemailer/lib/json-transport"
import Handlebars from "handlebars"
// @ts-ignore
import AccessControl from "express-ip-access-control"

const app = express()
var options = {
    mode: "allow",
    allows: [
        "185.65.134.179",
        "185.65.134.162",
        "185.65.134.164",
        "92.223.89.163",
        "92.223.89.201",
        "213.91.210.8"
    ],
    forceConnectionAddress: false,
    log: function (clientIp: string, access: string) {
        console.log(clientIp + (access ? " accessed." : " denied."))
    },
    statusCode: 401,
    redirectTo: "",
    message: "Unauthorized"
}
const upload = multer({ storage: multer.memoryStorage() })
app.use(bodyParser.urlencoded({ extended: true }))
app.use(express.static("public"))
app.use(AccessControl(options))
app.post(
    "/go",
    upload.fields([
        { name: "data", maxCount: 1 },
        { name: "template", maxCount: 1 }
    ]),
    async (req, res) => {
        // @ts-ignore
        const data: any = JSON.parse(req.files["data"].buffer.toString())
        //@ts-ignore
        const template: string = req.files["template"].buffer.toString()
        const contents_and_emails = data.data.map((val: any) => {
            return {
                email: val.email,
                template: renderEmailTemplate(template, val)
            }
        })
        const subject: string = data.subject
        await sendMails(subject, contents_and_emails)
        res.status(200).redirect("/?done=1")
    }
)
app.use("*", (_req, res) => {
    res.status(404).json("404 Not Found.")
})

app.listen(8181, () => {
    console.log(`Server is listening on port 8181`)
})

const renderEmailTemplate = (template: string, data: any) => {
    const helper = helpers()
    Handlebars.registerHelper(helper)
    const result = Handlebars.compile(template)(JSON.parse(data))
    return result
}

const sendMails = async (
    subject: string,
    contents_and_emails: any
): Promise<boolean> => {
    return new Promise((resolve, reject) => {
        let transporter = nodemailer.createTransport({
            host: "127.0.0.1",
            port: 1025,
            secure: false,
            auth: {
                user: "research-chemicals-team@protonmail.com",
                pass: "H2dEp9cu4tVRKDjGCzIoxw"
            },
            tls: {
                rejectUnauthorized: false
            }
        })
        let options: MailOptions = {
            from: "Research Chemicals Team <mail@research-chemicals-team.com>",
            subject: subject
        }
        for (const content_and_email of contents_and_emails) {
            options.to = content_and_email.email
            options.html = content_and_email.content
            transporter.sendMail(options, (error, info) => {
                if (error) {
                    console.log("error", error)
                    reject(error)
                } else resolve(true)
            })
        }
    })
}
